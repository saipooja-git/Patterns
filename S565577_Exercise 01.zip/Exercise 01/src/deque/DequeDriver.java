package deque;
//@Author: Sai Pooja Reddy 
			
import java.util.Deque;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Iterator;

public class DequeDriver {

    public static void main(String[] args) {
        Deque<String> deque = new LinkedList<>();
        deque.add("Alice");
        deque.add("Bob");
        deque.add("Charlie");
        deque.add("Grace");
        deque.add("Eve");
        deque.add("Bob");
        deque.add("Grace");

        System.out.println("************Elements in list******************");
        System.out.println("Elements in names: " + deque.size());
        System.out.println("Elements in names: " + deque);

        deque.add("Hannah");
        deque.addFirst("Jack");
        deque.addLast("Ivy");

        System.out.println("************Add Method******************");
        System.out.println("Elements in names: " + deque.size());
        System.out.println("Elements in names: " + deque);

        System.out.println("************Remove Method******************");
        System.out.println(deque.remove()); // Removes first element
        System.out.println(deque.removeFirst()); // Removes first element
        System.out.println(deque.removeLast()); // Removes last element

        System.out.println("Elements in names: " + deque);

        System.out.println("************removefirst and removelast occurance Method******************");
        deque.removeFirstOccurrence("Bob");
        deque.removeLastOccurrence("Grace");

        System.out.println("Elements in names: " + deque);

        System.out.println("************poll Method******************");
        System.out.println(deque.poll()); // Removes and returns the first element
        System.out.println(deque.pollFirst()); // Removes and returns the first element
        System.out.println(deque.pollLast()); // Removes and returns the last element

        System.out.println("Elements in names: " + deque);

        System.out.println("************peek Method******************");
        System.out.println(deque.peek()); // Retrieves but does not remove the first element
        System.out.println(deque.peekFirst()); // Retrieves but does not remove the first element
        System.out.println(deque.peekLast()); // Retrieves but does not remove the last element

        System.out.println("Elements in names: " + deque);

        deque.push("Henry");

        System.out.println("************push Method******************");
        System.out.println("Elements in names: " + deque);

        System.out.println("************pop Method******************");
        System.out.println(deque.pop()); // Removes and returns the first element

        System.out.println("Elements in names: " + deque);

        System.out.println("************Get Method******************");
        System.out.println(deque.getFirst()); // Retrieves but does not remove the first element
        System.out.println(deque.getLast()); // Retrieves but does not remove the last element

        System.out.println("Elements in names: " + deque);

        System.out.println("************Contains Method******************");
        System.out.println(deque.contains("Eve")); // Checks if "Eve" is in the Deque

        System.out.println("Elements in names: " + deque);

        System.out.println("************Iterator Method******************");
        Iterator<String> iterator = deque.iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }

        System.out.println("************Decending Iterator Method******************");
        Iterator<String> descendingIterator = ((LinkedList<String>) deque).descendingIterator();
        while (descendingIterator.hasNext()) {
            System.out.println(descendingIterator.next());
        }

        System.out.println("************ListIterator Method******************");
        ListIterator<String> listIterator = ((LinkedList<String>) deque).listIterator(deque.size());
        while (listIterator.hasPrevious()) {
            System.out.println(listIterator.previous());
        }
    }
}
