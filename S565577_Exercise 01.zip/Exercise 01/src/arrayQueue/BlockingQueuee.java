package arrayQueue;
//@Author: Sai Pooja Reddy 

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class BlockingQueuee {

    public static void main(String[] args) throws InterruptedException {
        // Create a BlockingQueue with a capacity of 4
        BlockingQueue<String> fruits = new ArrayBlockingQueue<>(4);
        
        // Add elements to the queue
        fruits.add("Mango");
        fruits.add("CustardApple");
        fruits.offer("Grapes"); // Returns false if full
        fruits.offer("Kiwi"); // Returns false if full
        
        // Print the size and elements of the queue
        System.out.println("Size of Fruits: " + fruits.size());
        System.out.println("Elements in Fruits: " + fruits);
        
        String removedFruit =fruits.poll();
        System.out.println("Removing the element in Fruits:"+ removedFruit);
        fruits.add("Orange");
        System.out.println("Elements in Fruits:"+fruits);
        
        System.out.println("Peek the element in Fruits:"+fruits.peek());
        String taken = fruits.take();
        System.out.println("Take an element in Fruits:"+taken);
        
        System.out.println("Size of Fruits:"+fruits.size());
    }}
