package bookmanagement;
//@Author: Sai Pooja Reddy 

import java.util.Objects;

public class Book {
    private String title;
    private int isbn;

    // Constructor
    public Book(String title, int isbn) {
        this.title = title;
        this.isbn = isbn;
    }


    // Overriding equals to compare by ISBN
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Book book = (Book) obj;
        return isbn == book.isbn;
    }

    // Overriding hashCode based on ISBN
    @Override
    public int hashCode() {
        return Objects.hash(isbn);
    }
    
    


    public String getTitle() {
        return title;
    }

    public int getIsbn() {
        return isbn;
    }
  
    }

