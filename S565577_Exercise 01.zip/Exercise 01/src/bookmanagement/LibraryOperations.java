package bookmanagement;
//@Author: Sai Pooja Reddy 

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.Set;
import java.util.stream.Collectors;

public class LibraryOperations {
    private LinkedList<Book> bookList;

    // No-arg constructor
    public LibraryOperations() {
        bookList = new LinkedList<>();
    }

    // Getter for bookList
    public LinkedList<Book> getBookList() {
        return bookList;
    }

    // Method to add books from a file
    public void addBooks(String fileName) throws FileNotFoundException {
        File file = new File(fileName);
        Scanner x = new Scanner(file);

        while (x.hasNextLine()) {
            String title = x.nextLine().trim();

            if (x.hasNextLine()) {
                String isbnStr = x.nextLine().trim();

                try {
                    int isbn = Integer.parseInt(isbnStr);
                    Book book = new Book(title, isbn);
                    bookList.add(book);
                } catch (NumberFormatException e) {
                    System.out.println("Invalid ISBN format: " + isbnStr);
                }
            } else {
                System.out.println("Missing ISBN for title: " + title);
            }
        }

        x.close();
    }

    // Method to remove duplicate books based on ISBN
    public void removeDuplicateBooks() {
        Set<Integer> seenIsbn = new HashSet<>();
        LinkedList<Book> uniqueBooks = new LinkedList<>();

        for (Book book : bookList) {
            if (seenIsbn.add(book.getIsbn())) {
                uniqueBooks.add(book);
            }
        }

        bookList = uniqueBooks;
    }

    // Recursive method to display duplicate book titles
    public String displayDuplicateBookTitlesByRecursion(Iterator<Book> iterator, Set<Integer> seen, Set<String> duplicates) {
        if (!iterator.hasNext()) {
            return duplicates.stream().collect(Collectors.joining(", "));
        }

        Book current = iterator.next();
        if (!seen.add(current.getIsbn())) {
            duplicates.add(current.getTitle());
        }

        return displayDuplicateBookTitlesByRecursion(iterator, seen, duplicates);
    }
}
