package bookmanagement;
//@Author: Sai Pooja Reddy 

import java.io.IOException;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;

public class LibraryDriver {

    public static void main(String[] args) throws IOException {
        LibraryOperations libraryOne = new LibraryOperations();
        LibraryOperations libraryTwo = new LibraryOperations();
        
        // Provide the correct path to your input file
        libraryOne.addBooks("input.txt");
        libraryTwo.addBooks("input.txt");
        
        System.out.println("Library one: ");
        displayData(libraryOne.getBookList());

        System.out.println();
        
        libraryOne.removeDuplicateBooks();
        System.out.println("Library one without duplicates: ");
        displayData(libraryOne.getBookList());

        System.out.println();
        
        System.out.println("Library two: ");
        displayData(libraryTwo.getBookList());

        System.out.println();
        
        // Initialize HashSet for seen ISBNs and duplicate titles
        Set<Integer> seenIsbn = new HashSet<>();
        Set<String> duplicateTitles = new HashSet<>();
        
        // Call the recursive method with the necessary parameters
        String duplicateTitlesStr = libraryTwo.displayDuplicateBookTitlesByRecursion(
            libraryTwo.getBookList().iterator(), 
            seenIsbn, 
            duplicateTitles
        );
        
        System.out.println("Library two duplicate book titles: ");
        System.out.println(duplicateTitlesStr);
    }
    
    // Method to display data in the book list
    public static void displayData(LinkedList<Book> bookList) {
        System.out.print("{");
        for (Book eachBook : bookList) {
            System.out.print(eachBook.getIsbn() + ", " + eachBook.getTitle() + "; ");
        }
        System.out.println("}");
    }
}
